(() => {
  const KEY = 'mediline_cart_v1';
  const cfg = window.MedilineStorefront || {};
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (_) { return []; } };
  const write = (items) => { localStorage.setItem(KEY, JSON.stringify(items)); refreshCount(); };
  const refreshCount = () => { const count = read().reduce((s, x) => s + Number(x.quantity || 0), 0); document.querySelectorAll('.js-cart-count').forEach(el => el.textContent = String(count)); };
  const add = (id, variationId=0) => { const items = read(); const found = items.find(x => Number(x.product_id) === Number(id) && Number(x.variation_id||0) === Number(variationId||0)); if (found) found.quantity += 1; else items.push({product_id:Number(id), variation_id:Number(variationId||0), quantity:1}); write(items); };
  document.addEventListener('click', (e) => { const btn = e.target.closest('.js-add-cart'); if (!btn) return; const select = btn.dataset.variationPicker ? document.querySelector('.js-variation-select') : null; const variationId = select ? Number(select.value||0) : Number(btn.dataset.variationId||0); add(btn.dataset.productId, variationId); const original=btn.textContent; btn.textContent = cfg.i18n?.added || 'Added'; setTimeout(() => btn.textContent = original, 900); });
  async function product(id) { const r = await fetch(`${cfg.rest}/products/${encodeURIComponent(id)}?lang=${encodeURIComponent(cfg.lang || 'en')}`); if (!r.ok) throw new Error('Product unavailable'); return (await r.json()).item; }
  async function renderCart() {
    const root = document.querySelector('.js-cart-items'); if (!root) return;
    const items = read(); if (!items.length) { root.innerHTML = '<div class="empty-state"><h2>Your cart is empty.</h2></div>'; document.querySelector('.js-cart-total').textContent = `0.00 ${cfg.currency || ''}`; return; }
    let total = 0; const rows = [];
    for (const line of items) { try { const p = await product(line.product_id); const variation=(p.variations||[]).find(v=>Number(v.id)===Number(line.variation_id||0)); const unit=variation?Number(variation.price||0):Number(p.price||0); const label=variation?Object.values(variation.attributes||{}).filter(Boolean).join(' / '):''; total += unit * Number(line.quantity || 1); const key=`${p.id}:${Number(line.variation_id||0)}`; rows.push(`<article class="cart-row"><div><b>${escapeHtml(p.name || '')}</b><small>${escapeHtml(label || p.sku || '')}</small></div><div class="cart-qty"><button data-minus="${key}">−</button><span>${line.quantity}</span><button data-plus="${key}">+</button></div><strong>${(unit*Number(line.quantity||1)).toFixed(2)} ${escapeHtml(p.currency||cfg.currency||'')}</strong></article>`); } catch (_) {} }
    root.innerHTML = rows.join('') || '<div class="empty-state"><h2>No available items.</h2></div>'; document.querySelector('.js-cart-total').textContent = `${total.toFixed(2)} ${cfg.currency || ''}`;
  }
  const escapeHtml = (s) => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
  document.addEventListener('click', (e) => { const plus=e.target.closest('[data-plus]'), minus=e.target.closest('[data-minus]'); if(!plus&&!minus)return; const key=String((plus||minus).dataset[plus?'plus':'minus']).split(':'); const id=Number(key[0]), variationId=Number(key[1]||0); let items=read(); const row=items.find(x=>Number(x.product_id)===id && Number(x.variation_id||0)===variationId); if(!row)return; row.quantity += plus?1:-1; items=items.filter(x=>x.quantity>0); write(items); renderCart(); });
  document.addEventListener('click', async (e) => { const btn=e.target.closest('.js-checkout'); if(!btn)return; const items=read(); if(!items.length)return; btn.disabled=true; try { const r=await fetch(`${cfg.rest}/checkout`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items})}); const data=await r.json(); if(!r.ok||!data.checkout_url)throw new Error(data.message||'Checkout failed'); window.location.href=data.checkout_url; } catch(err) { alert(err.message || cfg.i18n?.checkoutError || 'Checkout could not be started.'); btn.disabled=false; } });
  refreshCount(); renderCart();
})();

document.addEventListener('change',(e)=>{const s=e.target.closest('.js-variation-select');if(!s)return;const o=s.options[s.selectedIndex];const price=document.querySelector('[data-product-price]');if(price)price.textContent=`${Number(o.dataset.price||0).toFixed(2)} ${s.dataset.currency||''}`;});
