<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MEDILINE_STOREFRONT_VERSION', '1.0.0' );
define( 'MEDILINE_STOREFRONT_DIR', get_template_directory() );
define( 'MEDILINE_STOREFRONT_URI', get_template_directory_uri() );

function mediline_sf_has_core() { return function_exists( 'mediline_store_get_products' ); }

function mediline_sf_assets() {
	wp_enqueue_style( 'mediline-storefront', MEDILINE_STOREFRONT_URI . '/assets/css/store.css', array(), MEDILINE_STOREFRONT_VERSION );
	wp_enqueue_script( 'mediline-storefront', MEDILINE_STOREFRONT_URI . '/assets/js/store.js', array(), MEDILINE_STOREFRONT_VERSION, true );
	wp_localize_script( 'mediline-storefront', 'MedilineStorefront', array(
		'rest' => esc_url_raw( rest_url( 'mediline-store/v1' ) ),
		'cartUrl' => esc_url_raw( mediline_sf_route_url( 'cart' ) ),
		'lang' => mediline_sf_lang(),
		'currency' => function_exists( 'mediline_store_currency' ) ? mediline_store_currency() : 'EUR',
		'i18n' => array( 'added' => 'Added to cart', 'checkoutError' => 'Checkout could not be started.' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'mediline_sf_assets' );

function mediline_sf_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	register_nav_menus( array( 'primary' => __( 'Primary navigation', 'mediline-storefront' ) ) );
}
add_action( 'after_setup_theme', 'mediline_sf_setup' );

function mediline_sf_lang() {
	return function_exists( 'mediline_store_current_language' ) ? mediline_store_current_language() : 'en';
}

function mediline_sf_route_url( $path = '', $lang = '' ) {
	if ( function_exists( 'mediline_store_route_url' ) ) { return mediline_store_route_url( $path, $lang ); }
	return home_url( '/' . ltrim( $path, '/' ) );
}

function mediline_sf_register_routes() {
	add_rewrite_tag( '%mediline_product%', '([^&]+)' );
	add_rewrite_tag( '%mediline_category%', '([^&]+)' );
	add_rewrite_tag( '%mediline_cart%', '([01])' );
	add_rewrite_tag( '%mediline_store_lang%', '([a-z]{2,8})' );

	$languages = function_exists( 'mediline_store_languages' ) ? mediline_store_languages() : array( 'en' );
	$primary   = function_exists( 'mediline_store_primary_language' ) ? mediline_store_primary_language() : 'en';
	foreach ( $languages as $lang ) {
		$lang = sanitize_key( $lang );
		if ( ! $lang || $lang === $primary ) { continue; }
		add_rewrite_rule( '^' . preg_quote( $lang, '/' ) . '/?$', 'index.php?mediline_store_lang=' . $lang, 'top' );
		add_rewrite_rule( '^' . preg_quote( $lang, '/' ) . '/product/([^/]+)/?$', 'index.php?mediline_store_lang=' . $lang . '&mediline_product=$matches[1]', 'top' );
		add_rewrite_rule( '^' . preg_quote( $lang, '/' ) . '/category/([^/]+)/?$', 'index.php?mediline_store_lang=' . $lang . '&mediline_category=$matches[1]', 'top' );
		add_rewrite_rule( '^' . preg_quote( $lang, '/' ) . '/cart/?$', 'index.php?mediline_store_lang=' . $lang . '&mediline_cart=1', 'top' );
	}
	add_rewrite_rule( '^product/([^/]+)/?$', 'index.php?mediline_product=$matches[1]', 'top' );
	add_rewrite_rule( '^category/([^/]+)/?$', 'index.php?mediline_category=$matches[1]', 'top' );
	add_rewrite_rule( '^cart/?$', 'index.php?mediline_cart=1', 'top' );
}
add_action( 'init', 'mediline_sf_register_routes' );

function mediline_sf_query_vars( $vars ) {
	$vars[] = 'mediline_product'; $vars[] = 'mediline_category'; $vars[] = 'mediline_cart'; $vars[] = 'mediline_store_lang';
	return $vars;
}
add_filter( 'query_vars', 'mediline_sf_query_vars' );

function mediline_sf_virtual_template( $template ) {
	if ( get_query_var( 'mediline_product' ) ) { return MEDILINE_STOREFRONT_DIR . '/product.php'; }
	if ( get_query_var( 'mediline_category' ) ) { return MEDILINE_STOREFRONT_DIR . '/category.php'; }
	if ( get_query_var( 'mediline_cart' ) ) { return MEDILINE_STOREFRONT_DIR . '/cart.php'; }
	if ( get_query_var( 'mediline_store_lang' ) ) { return MEDILINE_STOREFRONT_DIR . '/front-page.php'; }
	return $template;
}
add_filter( 'template_include', 'mediline_sf_virtual_template' );

function mediline_sf_virtual_status() {
	if ( get_query_var( 'mediline_product' ) || get_query_var( 'mediline_category' ) || get_query_var( 'mediline_cart' ) || get_query_var( 'mediline_store_lang' ) ) {
		global $wp_query; if ( $wp_query ) { $wp_query->is_404 = false; } status_header( 200 );
	}
}
add_action( 'template_redirect', 'mediline_sf_virtual_status' );

function mediline_sf_language_attributes( $output ) {
	$lang = mediline_sf_lang();
	$html_code = 'sp' === $lang ? 'es' : $lang;
	$output = preg_replace( '/lang=("|\')[^"\']+("|\')/', 'lang="' . esc_attr( $html_code ) . '"', $output );
	return $output;
}
add_filter( 'language_attributes', 'mediline_sf_language_attributes' );

function mediline_sf_document_title( $parts ) {
	if ( get_query_var( 'mediline_product' ) && mediline_sf_has_core() ) {
		$product = mediline_store_get_product( get_query_var( 'mediline_product' ), mediline_sf_lang() );
		if ( $product && $product->name ) { $parts['title'] = $product->name; }
	} elseif ( get_query_var( 'mediline_category' ) ) {
		$parts['title'] = ucwords( str_replace( '-', ' ', sanitize_title( get_query_var( 'mediline_category' ) ) ) );
	} elseif ( get_query_var( 'mediline_cart' ) ) { $parts['title'] = 'Cart'; }
	return $parts;
}
add_filter( 'document_title_parts', 'mediline_sf_document_title' );

function mediline_sf_activate() { mediline_sf_register_routes(); flush_rewrite_rules(); }
add_action( 'after_switch_theme', 'mediline_sf_activate' );

function mediline_sf_money( $amount, $currency = 'EUR' ) {
	return esc_html( number_format_i18n( (float) $amount, 2 ) . ' ' . strtoupper( $currency ) );
}

function mediline_sf_product_url( $product ) { return mediline_sf_route_url( 'product/' . rawurlencode( $product->slug ) ); }
function mediline_sf_category_url( $category ) { return mediline_sf_route_url( 'category/' . rawurlencode( $category->slug ) ); }

function mediline_sf_product_card( $product ) {
	$image = ! empty( $product->images[0]['src'] ) ? $product->images[0]['src'] : ( ! empty( $product->images[0]['url'] ) ? $product->images[0]['url'] : '' );
	?>
	<article class="product-card">
		<a class="product-card__media" href="<?php echo esc_url( mediline_sf_product_url( $product ) ); ?>">
			<?php if ( $image ) : ?><img loading="lazy" src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $product->name ); ?>"><?php else : ?><span class="product-placeholder">M</span><?php endif; ?>
		</a>
		<div class="product-card__body">
			<div class="product-card__meta"><span><?php echo esc_html( $product->sku ); ?></span><span><?php echo esc_html( strtoupper( $product->stock_status ) ); ?></span></div>
			<h3><a href="<?php echo esc_url( mediline_sf_product_url( $product ) ); ?>"><?php echo esc_html( $product->name ); ?></a></h3>
			<p><?php echo wp_kses_post( wp_trim_words( wp_strip_all_tags( $product->short_description ), 18 ) ); ?></p>
			<div class="product-card__foot"><strong><?php echo mediline_sf_money( $product->price, $product->currency ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong><?php if ( 'variable' === $product->type && ! empty( $product->variations ) ) : ?><a class="button button--dark" href="<?php echo esc_url( mediline_sf_product_url( $product ) ); ?>">Choose</a><?php else : ?><button type="button" class="button button--dark js-add-cart" data-product-id="<?php echo esc_attr( $product->id ); ?>">Add</button><?php endif; ?></div>
		</div>
	</article>
	<?php
}
